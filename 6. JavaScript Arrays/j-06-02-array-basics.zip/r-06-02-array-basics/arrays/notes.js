const notes = ['Note 1', 'Note 2', 'Note 3']

console.log(notes.length)
console.log(notes[notes.length - 2])