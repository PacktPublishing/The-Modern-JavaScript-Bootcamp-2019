let city = 'Philadelphia'
let country = 'United States'
let location = city + ', ' + country

console.log(location)