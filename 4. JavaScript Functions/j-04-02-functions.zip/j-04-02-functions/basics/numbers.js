let age = 26
let dogYears = (age + 1) / 7

console.log(dogYears)

// Challenge area

let studentScore = 41
let maxScore = 100
let percent = (studentScore / maxScore) * 100

console.log(percent)