// 1. You can't define a variable more than once
let petName = 'Hal'

petName = 'Spot'

console.log(petName)

// 2. There are rules related to variable names
let test_ = 2
let result = 3 + 4

// 3. Variable names cannot be reserved keywords
// let let = 12