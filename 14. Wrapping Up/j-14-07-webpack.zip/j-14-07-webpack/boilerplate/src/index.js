const name = 'Mike'
console.log(name)

class Hangman {
    myMethod() {
        return 'Testing'
    }
}
const hangman = new Hangman()
console.log(hangman.myMethod())