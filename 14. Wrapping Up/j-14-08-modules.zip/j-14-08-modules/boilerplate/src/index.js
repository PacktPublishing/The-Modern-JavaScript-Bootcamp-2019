import { add, name } from './utilities'
import { scream } from './scream'

console.log('index.js')
console.log(add(32, 1))
console.log(scream(name))