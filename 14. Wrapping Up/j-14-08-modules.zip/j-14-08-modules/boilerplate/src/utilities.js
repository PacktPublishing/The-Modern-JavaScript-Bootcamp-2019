console.log('utilites.js')

export const add = (a, b) => a + b

export const name = 'Andrew'