const name = 'Jen'
console.log(name)

class Hangman {
    myMethod() {
        return 'Testing'
    }
}