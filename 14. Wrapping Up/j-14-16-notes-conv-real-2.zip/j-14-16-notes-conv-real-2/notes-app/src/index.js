import { getNotes, createNote } from './notes'

console.log(getNotes())
createNote()
console.log(getNotes())