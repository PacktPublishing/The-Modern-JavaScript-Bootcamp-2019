import otherSquare, { add, name } from './utilities'
import otherScream from './scream'

console.log('index.js')
console.log(add(32, 4))
console.log(otherScream(name))
console.log(otherSquare(10))