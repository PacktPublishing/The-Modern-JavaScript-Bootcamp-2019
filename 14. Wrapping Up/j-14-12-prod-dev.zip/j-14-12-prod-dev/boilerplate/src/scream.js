const scream = (text) => `${text.toUpperCase()}!`

export { scream as default }