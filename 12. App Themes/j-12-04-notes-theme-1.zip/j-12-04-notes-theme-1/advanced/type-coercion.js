// Type Coercion - a string, a number, a boolean

const value = false + 12
const type = typeof value
console.log(type)
console.log(value)